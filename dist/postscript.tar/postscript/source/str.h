/*
 * Copyright (C) Crispin Goswell 1987, All Rights Reserved.
 */

char *strcat (), *strncat ();
int strcmp (), strncmp (), strlen (), strspn (), strcspn ();
