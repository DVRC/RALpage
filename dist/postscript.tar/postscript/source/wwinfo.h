Now that I've gotten your attention...

If your system doesn't have the wwinfo.h file, that probably means
that you don't have the ww window manager, which is rumored to be
available only to academic sites in the U.K.  In that case, a version
of the Postscript Interpreter compiled to produce output for ww
is probably worthless to you.

Please examine the file source/makefile and select a version that is
appropriate for you--possible choices include "sunPS", "XPS", and
"xps".

				_.John G. Myers

